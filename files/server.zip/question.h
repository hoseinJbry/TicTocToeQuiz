#ifndef QUESTION_H
#define QUESTION_H
#include <QMainWindow>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkAccessManager>



class question : public QMainWindow
{
    Q_OBJECT
public:
    question();
    QString  apireply(QString );

private:
    QNetworkAccessManager m_manager;
    QNetworkRequest request;
    QUrl url;


};

#endif // QUESTION_H

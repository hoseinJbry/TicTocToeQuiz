#include "question.h"

question::question() {


}



QString  question::apireply(QString Qtype)
{



    url = QUrl("https://questionbank.liara.run/api/YWxpIHJhZml6YWRlaCxob3NlaW4gamFiYXJpLGQxQkVRNWYyMjUxZA/question?type="+Qtype);
    request = QNetworkRequest(url);
    QNetworkReply* reply = m_manager.get(request);
    connect(reply, &QNetworkReply::finished, [reply]() {

        QString ReplyText = reply->readAll();
        qDebug() << ReplyText;

        QJsonDocument doc = QJsonDocument::fromJson(ReplyText.toUtf8());
        QJsonObject obj = doc.object();


    });

}
